import { Col, Space, Row } from 'antd';
import './style.css';
import { useNavigate } from 'react-router-dom'; 

const CardTitle = ({ title, id }) => {
    const navigate = useNavigate();
    const handleDetailsClick = () => {
        navigate(`/task/${id}`); // Перенаправление на страницу с id
    };


    return (
        <Row>
            <Col span={12}>
                {title}
            </Col>
            <Col span={12} style={{ textAlign: "right"}}>
                <span className='task-info-link' onClick={handleDetailsClick}>
                    Подробнее
                </span>
            </Col>
        </Row>
  
    );
};

export default CardTitle;