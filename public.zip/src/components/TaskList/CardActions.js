import React, { useEffect, useState } from 'react';
import { Checkbox, Col, Row } from 'antd';
import './style.css';
import { List } from 'antd/es/form/Form';

const CardActions = ({ actions }) => {

    const [items, setItems] = useState(actions);

    useEffect(() => {
        setItems(actions);
    }, [actions]);


    const handleCheckboxChange = (index) => {
        const updatedItems = items.map((item, i) => 
            i === index ? { ...item, isComplite: !item.isComplite } : item
        );
        setItems(updatedItems);
    };

    if (!actions) return ;

    return (
        <>
            {
                items?.map((item,index) => (
                    <Row style={{ backgroundColor: item.isComplite ? "#E7FFE6" : "#F6F6F6", padding: "10px", margin: "5px 0 0 0" }} className='action-info'>
                        <Col span={23}>
                            {item.title}
                        </Col>
                        <Col span={1}>
                            <Checkbox
                                checked={item.isComplite}
                                className='task-cb'
                                onChange={() => handleCheckboxChange(index)}
                            />
                        </Col>
                    </Row>
                ))
            }
        </>

    );
};

export default CardActions;