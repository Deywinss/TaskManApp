import React, { useState, useEffect } from 'react';
import { List, Dropdown, Button, Menu, Tag, Checkbox, Space, Card } from 'antd';
import { fetchTasks } from '../../api/axios';
import { DownOutlined } from '@ant-design/icons';
import './style.css';
import CardTitle from './CardTitle';
import CardActions from './CardActions';

const TaskList = ({ onTaskSelect }) => {
    const [tasks, setTasks] = useState([]);
    const [taskType, setTaskType] = useState('all');

    useEffect(() => {
        const loadTasks = async () => {
            const data = await fetchTasks(taskType);
            setTasks(data);
        };
        loadTasks();
    }, [taskType]);

    const menu = (
        <Menu
            onClick={({ key }) => setTaskType(key)}
            items={[
                { key: 'all', label: 'Все задачи' },
                { key: 'completed', label: 'Завершенные' },
                { key: 'pending', label: 'Ожидающие' },
            ]}
        />
    );


    const typeValue = taskType === 'all' ? 'Все задачи' : taskType === 'completed' ? 'Завершенные' : 'Ожидающие';


    return (
        <div>
            <div className='tasks'>

                <span>Выбор типа задачи</span>
                <br />
                <Dropdown overlay={menu} placement="bottomLeft" className='dd-item-type'>
                    <Button>
                        <Space align="start">
                            <span>{typeValue}</span>
                            <DownOutlined />
                        </Space>
                    </Button>
                </Dropdown>
            </div>

            <List
                dataSource={tasks}
                renderItem={(item) => (
                    <List.Item >
                        <Card
                            title={<CardTitle title={item.title} id={item.id}/>}
                            style={{ width: "95%" }}
                        >
                          <CardActions actions={item.actions} />
                        </Card>
                    </List.Item>
                )}
            />

        </div>
    );
};

export default TaskList;