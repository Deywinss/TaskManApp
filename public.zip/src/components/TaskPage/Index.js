import React, { useState } from 'react';
import TaskList from '../TaskList/Index';
import { Layout } from 'antd';

import { Row, Col } from 'antd';

const TaskPage = () => {
    const { Content, Header } = Layout;
    const [selectedTask, setSelectedTask] = useState(null);

    return (
        <>
            <Header className='header'>
                <span>Задачи</span>
            </Header>
            <Content style={{ paddingLeft: '20px', backgroundColor: '#fff' }}>
                <TaskList onTaskSelect={setSelectedTask} />
            </Content>
        </>
    );
};

export default TaskPage;

