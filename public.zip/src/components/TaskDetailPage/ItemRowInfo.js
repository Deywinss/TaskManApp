import { Row, Col } from "antd";

export const ItemRowInfo = ({ title, value }) => {
    return (
        <div>
            <Row>
            <Col span={10}>{title}</Col>
            <Col span={12} style={{textAlign: "right"}}>{value}</Col>
            </Row>
        </div>
    );
};

