import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { LeftOutlined } from '@ant-design/icons';

import { Button, Card, Layout, Row, Space } from 'antd';
import { fetchTaskDetails } from '../../api/axios';
import { ItemRowInfo } from './ItemRowInfo';
import CardActions from '../TaskList/CardActions';


export const TaskDetailPage = () => {
    const { Content, Header } = Layout;
    const { id } = useParams();
    const [task, setTask] = useState([]);
    const navigate = useNavigate();


    useEffect(() => {
        const loadTask = async () => {
            const data = await fetchTaskDetails(id);
            setTask(data)
        };
        loadTask();
    }, [id]);

    const formatDate = function formatDate(date) {
        date = new Date(date);
        return (
            [
                (date.getDate()),
                (date.getMonth() + 1),
                date.getFullYear(),
            ].join('.')
        );
    }

    const getPriority = (id) => {
        if (id == 1) {
            return <span style={{ backgroundColor: "#87D068", padding: "5px", color: "#FFF" }}>Не срочно, но важно</span>
        }
        else return (<span>Стандартный</span>)
    }

    return (
        <>
            <Header className='header'>
                <Space>
                    <LeftOutlined onClick={() => navigate("/")} />
                    <span>{task.title}</span>
                </Space>
            </Header>
            <Content style={{ paddingLeft: '20px', backgroundColor: '#fff' }}>
                <Card>
                    <ItemRowInfo title='Дата:' value={formatDate(task.date)} />
                    <ItemRowInfo title='Приоритет:' value={getPriority(task.priority)} />
                    <hr />
                    <ItemRowInfo title='Подзадачи:' />
                    <CardActions actions={task.actions} />
                </Card>
                <br />
                <Button type="primary" block style={{ width: "95%"}}>
                    Удалить
                </Button>
                <br />
                <Space style={{ marginTop: "15px"}}>
                    <span style={{ fontSize: "19px" }}>Комментарии:</span>
                </Space>
                {task.comments?.map((item, index) =>
                    <>
                        <Row style={{ marginTop: "10px"}}><span>{item.author} {formatDate(task.date)}</span></Row>
                        <Row><span style={{ fontSize: "14px", lineHeight: "22px" }}>{item.text}</span></Row>
                    </>
                )}
            </Content>
        </>
    );
};

