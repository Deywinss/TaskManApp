import React, { useState, useEffect } from 'react';
import { Card, Button } from 'antd';
import { fetchTaskDetails } from '../api/axios';

const TaskDetail = ({ taskId, onBack }) => {
    const [task, setTask] = useState(null);

    useEffect(() => {
        const loadTaskDetails = async () => {
            const data = await fetchTaskDetails(taskId);
            setTask(data);
        };
        loadTaskDetails();
    }, [taskId]);

    if (!task) return <div>Загрузка...</div>;

    return (
        <Card
            title={task.title}
            extra={<Button onClick={onBack}>Назад</Button>}
        >
            <p>{task.description}</p>
            <p>Статус: {task.status}</p>
        </Card>
    );
};

export default TaskDetail;