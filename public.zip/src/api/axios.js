import axios from 'axios';

const API_URL = 'http://localhost:5048/api';

export const fetchTasks = async (type) => {
    const response = await axios.get(`${API_URL}/tasks`, { params: { type } });
    return response.data;
};

export const fetchTaskDetails = async (id) => {
    const response = await axios.get(`${API_URL}/task/${id}`);
    return response.data;
};